package ru.vakhta.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.os.Handler;
import android.os.Looper;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        WeatherRefreshWorker.schedule(this);
        getWindow().setStatusBarColor(Color.rgb(20, 30, 42));
        getWindow().setNavigationBarColor(Color.rgb(20, 30, 42));
        webView = new WebView(this);
        WebView web = webView;
        web.setBackgroundColor(Color.rgb(20, 30, 42));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new VakhtaBridge(this, web), "VakhtaBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                openForecastFromIntent(getIntent());
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        openForecastFromIntent(intent);
    }
    private void openForecastFromIntent(Intent intent) {
        if (intent == null || webView == null) return;
        String kind = intent.getStringExtra("show_weather_forecast");
        if (!"home".equals(kind) && !"work".equals(kind)) return;
        String safeKind = "home".equals(kind) ? "home" : "work";
        webView.evaluateJavascript("if(window.openVakhtaForecast){window.openVakhtaForecast('" + safeKind + "');}", null);
        intent.removeExtra("show_weather_forecast");
    }
    public static class VakhtaBridge {
        private final Context context; private final SharedPreferences prefs; private final WebView web;
        private final ExecutorService executor = Executors.newSingleThreadExecutor();
        private final Handler mainHandler = new Handler(Looper.getMainLooper());
        VakhtaBridge(Context c, WebView w) { context=c.getApplicationContext(); web=w; prefs=context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE); }
        @JavascriptInterface public void loadMenu(String date) {
            if (date == null || !date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                deliverMenu(date == null ? "" : date, "", "Некорректная дата"); return;
            }
            executor.execute(() -> {
                HttpURLConnection connection = null;
                try {
                    String url = "https://menu.omc.ru/menus?date=" + date
                        + "&object_guid=84dd86ef-7c1b-4973-bfda-88dd8b572bc6&lang=ru&is_duty_menu=0"
                        + "&type_menu_guid=e8b804fb-6233-11e7-80da-005056883dd6&view=&type_price_guid=";
                    connection = (HttpURLConnection) new URL(url).openConnection();
                    connection.setRequestMethod("GET"); connection.setConnectTimeout(15000); connection.setReadTimeout(20000);
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36");
                    connection.setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9");
                    int code = connection.getResponseCode();
                    if (code < 200 || code >= 300) throw new java.io.IOException("HTTP " + code);
                    StringBuilder body = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                        String line; while ((line = reader.readLine()) != null) body.append(line).append('\\n');
                    }
                    deliverMenu(date, body.toString(), "");
                } catch (Exception e) {
                    deliverMenu(date, "", e.getMessage() == null ? "Ошибка загрузки" : e.getMessage());
                } finally { if (connection != null) connection.disconnect(); }
            });
        }
        private void deliverMenu(String date, String html, String error) {
            try {
                JSONObject payload = new JSONObject(); payload.put("date", date); payload.put("html", html); payload.put("error", error);
                String json = payload.toString();
                mainHandler.post(() -> web.evaluateJavascript("if(window.onVakhtaMenuHtml){const p=" + json + ";window.onVakhtaMenuHtml(p.date,p.html,p.error);}", null));
            } catch (Exception ignored) { }
        }
        @JavascriptInterface public String getOverrides() { return prefs.getString("overrides_json", "{}"); }
        @JavascriptInterface public void syncWeather(String weatherJson) {
            try {
                JSONObject incoming = new JSONObject(weatherJson == null ? "{}" : weatherJson);
                AppWidgetManagerHelper.mergeWeatherCache(context, incoming);
            } catch (Exception ignored) { }
            AppWidgetManagerHelper.refresh(context);
        }
        @JavascriptInterface public void syncState(String workedJson, String overridesJson, String extrasJson, String location, String periodsJson) {
            prefs.edit().putString("worked_json", workedJson)
                    .putString("overrides_json", overridesJson)
                    .putString("extras_json", extrasJson)
                    .putString("periods_json", periodsJson == null ? "[]" : periodsJson)
                    .putString("place", location == null ? "" : location).apply();
            try { JSONArray a=new JSONArray(workedJson); java.util.HashSet<String> days=new java.util.HashSet<>(); for(int i=0;i<a.length();i++) days.add(a.getString(i));
                SharedPreferences.Editor e=prefs.edit(); java.util.Map<String,?> all=prefs.getAll(); for(String k:all.keySet()) if(k.startsWith("worked_") && k.length()==17) e.remove(k); for(String day:days)e.putBoolean("worked_"+day,true); e.apply();
            } catch(Exception ignored) {}
            AppWidgetManagerHelper.refresh(context);
        }
    }
}
