package ru.vakhta.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.os.Handler;
import android.os.Looper;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        WeatherRefreshWorker.schedule(this);
        getWindow().setStatusBarColor(Color.rgb(20, 30, 42));
        getWindow().setNavigationBarColor(Color.rgb(20, 30, 42));
        webView = new WebView(this);
        WebView web = webView;
        web.setBackgroundColor(Color.rgb(20, 30, 42));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new VakhtaBridge(this, web), "VakhtaBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                openForecastFromIntent(getIntent());
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "if(window.isVakhtaRationOpen && window.isVakhtaRationOpen()){window.closeVakhtaRation(); 'closed';}else if(window.isVakhtaCanteenOpen && window.isVakhtaCanteenOpen()){window.closeVakhtaCanteen(); 'closed';}else if(window.isVakhtaForecastOpen && window.isVakhtaForecastOpen()){window.closeVakhtaForecast(); 'closed';}else if(window.isVakhtaPeriodsOpen && window.isVakhtaPeriodsOpen()){window.closeVakhtaPeriods(); 'closed';}else{'not-open';}",
                    value -> {
                        if (value == null || value.contains("not-open")) {
                            MainActivity.super.onBackPressed();
                        }
                    });
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        openForecastFromIntent(intent);
    }
    private void openForecastFromIntent(Intent intent) {
        if (intent == null || webView == null) return;
        String kind = intent.getStringExtra("show_weather_forecast");
        if (!"home".equals(kind) && !"work".equals(kind)) return;
        String safeKind = "home".equals(kind) ? "home" : "work";
        webView.evaluateJavascript("if(window.openVakhtaForecast){window.openVakhtaForecast('" + safeKind + "');}", null);
        intent.removeExtra("show_weather_forecast");
    }
    public static class VakhtaBridge {
        private final Context context; private final SharedPreferences prefs; private final WebView targetWebView;
        private final ExecutorService network=Executors.newSingleThreadExecutor();
        private final Handler main=new Handler(Looper.getMainLooper());
        VakhtaBridge(Context c, WebView w) { context=c.getApplicationContext(); targetWebView=w; prefs=context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE); }
        @JavascriptInterface public void fetchCanteenHtml(String date, String callback) {
            final String safeDate = (date != null && date.matches("\\d{4}-\\d{2}-\\d{2}")) ? date : new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
            network.execute(() -> {
                String html = ""; String error = "";
                HttpURLConnection conn = null;
                try {
                    String url = "https://menu.omc.ru/menus?date=" + URLEncoder.encode(safeDate, "UTF-8") + "&object_guid=84dd86ef-7c1b-4973-bfda-88dd8b572bc6&lang=ru&is_duty_menu=0&type_menu_guid=e8b804fb-6233-11e7-80da-005056883dd6&view=&type_price_guid=";
                    conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setRequestMethod("GET"); conn.setConnectTimeout(15000); conn.setReadTimeout(20000);
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");
                    conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8");
                    int code = conn.getResponseCode();
                    if (code < 200 || code >= 300) throw new java.io.IOException("HTTP " + code);
                    try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                        byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) { out.write(buf, 0, n); if (out.size() > 5 * 1024 * 1024) throw new java.io.IOException("Menu page too large"); }
                        html = out.toString("UTF-8");
                    }
                } catch (Exception e) { error = e.getMessage() == null ? "network error" : e.getMessage(); }
                finally { if (conn != null) conn.disconnect(); }
                final String resultHtml = html, resultError = error;
                main.post(() -> {
                    if (targetWebView == null) return;
                    String js = "window." + callback + " && window." + callback + "(" + JSONObject.quote(safeDate) + "," + JSONObject.quote(resultHtml) + "," + JSONObject.quote(resultError) + ");";
                    targetWebView.evaluateJavascript(js, null);
                });
            });
        }
        @JavascriptInterface public String getOverrides() { return prefs.getString("overrides_json", "{}"); }
        @JavascriptInterface public void syncWeather(String weatherJson) {
            try {
                JSONObject incoming = new JSONObject(weatherJson == null ? "{}" : weatherJson);
                AppWidgetManagerHelper.mergeWeatherCache(context, incoming);
            } catch (Exception ignored) { }
            AppWidgetManagerHelper.refresh(context);
        }
        @JavascriptInterface public void syncState(String workedJson, String overridesJson, String extrasJson, String location, String periodsJson) {
            prefs.edit().putString("worked_json", workedJson)
                    .putString("overrides_json", overridesJson)
                    .putString("extras_json", extrasJson)
                    .putString("periods_json", periodsJson == null ? "[]" : periodsJson)
                    .putString("place", location == null ? "" : location).apply();
            try { JSONArray a=new JSONArray(workedJson); java.util.HashSet<String> days=new java.util.HashSet<>(); for(int i=0;i<a.length();i++) days.add(a.getString(i));
                SharedPreferences.Editor e=prefs.edit(); java.util.Map<String,?> all=prefs.getAll(); for(String k:all.keySet()) if(k.startsWith("worked_") && k.length()==17) e.remove(k); for(String day:days)e.putBoolean("worked_"+day,true); e.apply();
            } catch(Exception ignored) {}
            AppWidgetManagerHelper.refresh(context);
        }
    }
}
