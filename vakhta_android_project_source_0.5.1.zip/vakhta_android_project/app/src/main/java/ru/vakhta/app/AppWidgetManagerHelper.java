package ru.vakhta.app;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.Iterator;

public final class AppWidgetManagerHelper {
    private AppWidgetManagerHelper() { }

    public static void refresh(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, VakhtaWidgetProvider.class));
        for (int id : ids) VakhtaWidgetProvider.update(context, manager, id);
    }

    /** Merge only supplied non-null weather fields so either the WebView or worker can refresh safely. */
    public static synchronized void mergeWeatherCache(Context context, JSONObject incoming) {
        if (incoming == null) return;
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        JSONObject existing;
        try { existing = new JSONObject(prefs.getString("weather_json", "{}")); }
        catch (Exception ignored) { existing = new JSONObject(); }
        for (String place : new String[]{"home", "work"}) {
            JSONObject fresh = incoming.optJSONObject(place);
            if (fresh == null) continue;
            JSONObject old = existing.optJSONObject(place);
            JSONObject merged;
            try { merged = old == null ? new JSONObject() : new JSONObject(old.toString()); }
            catch (Exception ignored) { merged = new JSONObject(); }
            Iterator<String> keys = fresh.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (fresh.isNull(key)) continue;
                try { merged.put(key, fresh.get(key)); }
                catch (Exception ignored) { }
            }
            try { existing.put(place, merged); } catch (Exception ignored) { }
        }
        prefs.edit().putString("weather_json", existing.toString()).apply();
    }
}
