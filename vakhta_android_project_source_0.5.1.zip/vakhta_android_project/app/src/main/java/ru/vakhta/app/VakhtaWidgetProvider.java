package ru.vakhta.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Home-screen widget for My Vakhta. The app calendar is the source of truth. */
public class VakhtaWidgetProvider extends AppWidgetProvider {
    private static final String ACTION_TOGGLE_DAY = "ru.vakhta.app.action.TOGGLE_DAY";
    private static final int COLOR_MUTED = Color.rgb(184, 198, 216);
    private static final int COLOR_TEXT = Color.WHITE;
    private static final int COLOR_GREEN = Color.rgb(91, 196, 155);
    private static final int COLOR_NIGHT = Color.rgb(66, 60, 115);
    private static final int COLOR_DAY = Color.rgb(37, 78, 88);
    private static final int COLOR_EXTRA = Color.rgb(36, 93, 145);
    private static final int COLOR_VACATION = Color.rgb(107, 76, 34);
    private static final int COLOR_SICK = Color.rgb(113, 59, 59);
    private static final int COLOR_HOME = Color.rgb(38, 56, 75);

    private static final int[] DAY_IDS = {
        R.id.day0, R.id.day1, R.id.day2, R.id.day3, R.id.day4, R.id.day5, R.id.day6
    };
    private static final int[] LABEL_IDS = {
        R.id.label0, R.id.label1, R.id.label2, R.id.label3, R.id.label4, R.id.label5, R.id.label6
    };
    private static final String[] DAY_NAMES = {"Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"};

    private static final class Period {
        final String start;
        final String end;
        final String type;
        final String label;

        Period(String start, String end, String type, String label) {
            this.start = start == null ? "" : start;
            this.end = end == null ? "" : end;
            this.type = type == null ? "" : type;
            this.label = label == null || label.trim().isEmpty() ? defaultLabel(this.type) : label;
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
        WeatherRefreshWorker.schedule(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle newOptions) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions);
        update(context, manager, appWidgetId);
    }

    static void update(Context context, AppWidgetManager manager, int widgetId) {
        SharedPreferences prefs = context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        Bundle options = manager.getAppWidgetOptions(widgetId);
        int width = options == null ? 0 : options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0);
        int height = options == null ? 0 : options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        boolean large = width >= 250 && (height == 0 || height >= 160);
        RemoteViews views = new RemoteViews(context.getPackageName(),
                large ? R.layout.widget_large : R.layout.widget_small);

        String today = iso(Calendar.getInstance());
        List<Period> periods = readPeriods(prefs);
        List<Period> extras = readExtras(prefs);
        // Extras are later in the app's period list and override the regular schedule when overlapping.
        List<Period> ordered = new ArrayList<>(periods);
        ordered.addAll(extras);
        Period active = periodOn(ordered, today);
        boolean working = isWorkingPeriod(active);
        Period nextPeriod = nextWorkPeriod(ordered, today);

        String target;
        String countLabel;
        String status;
        String shift;
        int progress = 0;
        if (working) {
            target = addDays(active.end, 1);
            countLabel = "дней до конца";
            status = "На вахте";
            shift = active.label;
            int total = Math.max(1, daysBetween(active.start, addDays(active.end, 1)));
            int elapsed = Math.max(0, daysBetween(active.start, today) + 1);
            progress = Math.min(100, Math.max(0, Math.round(elapsed * 100f / total)));
        } else {
            target = nextPeriod == null ? null : nextPeriod.start;
            countLabel = "дней до вахты";
            status = "Дома";
            shift = active != null && ("vacation".equals(active.type) || "sick".equals(active.type))
                    ? active.label : "Отдых";
        }
        int daysLeft = target == null ? -1 : Math.max(0, daysBetween(today, target));
        String place = prefs.getString("place", "");
        if (!"home".equals(place) && !"work".equals(place)) place = working ? "work" : "home";
        views.setTextViewText(R.id.widget_title, "МОЯ ВАХТА");
        views.setTextViewText(R.id.widget_status, working ? status + " · " + shift : status + " · " + shift);
        views.setTextColor(R.id.widget_status, working ? Color.WHITE : COLOR_GREEN);
        views.setTextViewText(R.id.widget_place,
                "home".equals(place) ? "Дом · Ангрен" : "Работа · Матросова");
        views.setTextViewText(R.id.widget_weather, readWeatherCondition(prefs, place));
        views.setTextViewText(R.id.widget_weather_humidity, readWeatherHumidity(prefs, place));
        views.setTextViewText(R.id.widget_weather_icon, readWeatherIcon(prefs, place));
        views.setTextViewText(R.id.widget_current_temp, readCurrentHourTemperature(prefs, place));
        views.setTextViewText(R.id.widget_daynight,
                "День " + readWeatherTemperature(prefs, place, "day", "max") + "\nНочь " + readWeatherTemperature(prefs, place, "night", "min"));
        views.setTextViewText(R.id.widget_countdown, daysLeft < 0 ? "—" : String.valueOf(daysLeft));
        views.setTextViewText(R.id.widget_count_label, daysLeft < 0 ? "нет даты" : countLabel);
        views.setTextViewText(R.id.widget_next,
                target == null ? "График дальше не задан" : "Следующая дата: " + formatDate(target));
        views.setProgressBar(R.id.widget_progress, 100, progress, false);

        Calendar monday = Calendar.getInstance();
        int dayOfWeek = monday.get(Calendar.DAY_OF_WEEK);
        monday.add(Calendar.DAY_OF_MONTH, -(dayOfWeek == Calendar.SUNDAY ? 6 : dayOfWeek - Calendar.MONDAY));
        for (int i = 0; i < 7; i++) {
            Calendar date = (Calendar) monday.clone();
            date.add(Calendar.DAY_OF_MONTH, i);
            String key = iso(date);
            views.setTextViewText(LABEL_IDS[i], DAY_NAMES[i]);

            boolean worked = isWorked(prefs, key);
            Period dayPeriod = periodOn(ordered, key);
            int background = backgroundFor(dayPeriod);
            if (worked) background = Color.rgb(42, 81, 70);
            views.setInt(DAY_IDS[i], "setBackgroundColor", background);
            String dayText = String.valueOf(date.get(Calendar.DAY_OF_MONTH));
            if (worked) dayText += "\n✓";
            views.setTextViewText(DAY_IDS[i], dayText);
            views.setTextColor(DAY_IDS[i], key.equals(today)
                    ? Color.rgb(246, 198, 91)
                    : (worked ? COLOR_GREEN : COLOR_TEXT));

            if (isWorkDay(ordered, key)) {
                Intent toggle = new Intent(context, VakhtaWidgetProvider.class);
                toggle.setAction(ACTION_TOGGLE_DAY);
                toggle.putExtra("date", key);
                toggle.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
                PendingIntent pending = PendingIntent.getBroadcast(context, widgetId * 10 + i,
                        toggle, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                views.setOnClickPendingIntent(DAY_IDS[i], pending);
            }
        }

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending = PendingIntent.getActivity(context, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openPending);

        Intent forecast = new Intent(context, MainActivity.class);
        forecast.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        forecast.putExtra("show_weather_forecast", "home".equals(place) ? "home" : "work");
        PendingIntent forecastPending = PendingIntent.getActivity(context, 20000 + widgetId, forecast,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_weather_panel, forecastPending);
        views.setOnClickPendingIntent(R.id.widget_weather, forecastPending);
        views.setOnClickPendingIntent(R.id.widget_weather_humidity, forecastPending);
        manager.updateAppWidget(widgetId, views);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (!ACTION_TOGGLE_DAY.equals(intent.getAction())) return;

        String date = intent.getStringExtra("date");
        if (date == null || date.length() != 10) return;
        SharedPreferences prefs = context.getSharedPreferences("vakhta_widget", Context.MODE_PRIVATE);
        boolean nextValue = !isWorked(prefs, date);
        JSONObject overrides;
        JSONArray workedDays;
        try { overrides = new JSONObject(prefs.getString("overrides_json", "{}")); }
        catch (Exception ignored) { overrides = new JSONObject(); }
        try { workedDays = new JSONArray(prefs.getString("worked_json", "[]")); }
        catch (Exception ignored) { workedDays = new JSONArray(); }

        overridesPut(overrides, date, nextValue);
        List<String> dates = new ArrayList<>();
        for (int i = 0; i < workedDays.length(); i++) {
            String saved = workedDays.optString(i, "");
            if (!saved.isEmpty() && !saved.equals(date) && !dates.contains(saved)) dates.add(saved);
        }
        if (nextValue && !dates.contains(date)) dates.add(date);
        JSONArray updatedWorked = new JSONArray();
        for (String value : dates) updatedWorked.put(value);
        prefs.edit()
                .putBoolean("worked_" + date, nextValue)
                .putString("overrides_json", overrides.toString())
                .putString("worked_json", updatedWorked.toString())
                .apply();

        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, VakhtaWidgetProvider.class));
        for (int id : ids) update(context, manager, id);
    }

    private static JSONObject readWeatherObject(SharedPreferences prefs, String place) {
        try {
            JSONObject all = new JSONObject(prefs.getString("weather_json", "{}"));
            return all.optJSONObject("home".equals(place) ? "home" : "work");
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String readWeatherCondition(SharedPreferences prefs, String place) {
        JSONObject w = readWeatherObject(prefs, place);
        if (w == null) return "Погода пока не загружена";
        String condition = w.optString("condition", "Погодные условия");
        int wind = w.optInt("wind", -1);
        String direction = w.optString("windDirection", "");
        if (wind >= 0) {
            condition += " · ветер " + wind + " км/ч";
            if (!direction.isEmpty() && !"—".equals(direction)) condition += " " + direction;
        }
        return condition;
    }

    private static String readWeatherHumidity(SharedPreferences prefs, String place) {
        JSONObject w = readWeatherObject(prefs, place);
        if (w == null || !w.has("humidity") || w.isNull("humidity")) return "Влажность —";
        return "Влажность " + w.optInt("humidity", -1) + "%";
    }

    /** Picks the saved hourly forecast for the current local hour of the selected place.
     * This runs during normal widget refreshes too, so it works without an internet connection. */
    private static String readCurrentHourTemperature(SharedPreferences prefs, String place) {
        JSONObject w = readWeatherObject(prefs, place);
        if (w == null) return "—°";
        JSONArray times = w.optJSONArray("hourlyTimes");
        JSONArray temps = w.optJSONArray("hourlyTemperatures");
        if (times == null || temps == null || times.length() == 0 || temps.length() == 0) {
            return readWeatherTemperature(prefs, place, "temperature", null);
        }

        ZoneId zone;
        try {
            String timezone = w.optString("timezone", "");
            zone = timezone.isEmpty() ? ZoneId.systemDefault() : ZoneId.of(timezone);
        } catch (Exception ignored) {
            zone = ZoneId.systemDefault();
        }
        LocalDateTime now = LocalDateTime.now(zone).withMinute(0).withSecond(0).withNano(0);
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        int best = -1;
        long bestDelta = Long.MAX_VALUE;
        int sameHourBest = -1;
        long sameHourDelta = Long.MAX_VALUE;
        for (int i = 0; i < times.length() && i < temps.length(); i++) {
            String rawTime = times.optString(i, "");
            try {
                LocalDateTime forecastTime = LocalDateTime.parse(rawTime, formatter);
                long delta = Math.abs(ChronoUnit.MINUTES.between(now, forecastTime));
                if (delta < bestDelta) {
                    bestDelta = delta;
                    best = i;
                }
                if (forecastTime.getHour() == now.getHour() && delta < sameHourDelta) {
                    sameHourDelta = delta;
                    sameHourBest = i;
                }
                if (forecastTime.getYear() == now.getYear()
                        && forecastTime.getDayOfYear() == now.getDayOfYear()
                        && forecastTime.getHour() == now.getHour()) {
                    best = i;
                    bestDelta = 0;
                    break;
                }
            } catch (Exception ignored) { }
        }
        // Prefer the same hour of day if today's timestamp is outside the saved forecast window.
        if (sameHourBest >= 0 && bestDelta != 0) best = sameHourBest;
        if (best < 0) return readWeatherTemperature(prefs, place, "temperature", null);
        double raw = temps.optDouble(best, Double.NaN);
        if (Double.isNaN(raw)) return readWeatherTemperature(prefs, place, "temperature", null);
        long value = Math.round(raw);
        return (value < 0 ? "−" + Math.abs(value) : String.valueOf(value)) + "°";
    }

    private static String readWeatherTemperature(SharedPreferences prefs, String place, String key, String fallbackKey) {
        JSONObject w = readWeatherObject(prefs, place);
        if (w == null) return "—°";
        String actualKey = key;
        if ((!w.has(actualKey) || w.isNull(actualKey)) && fallbackKey != null) actualKey = fallbackKey;
        if ((!w.has(actualKey) || w.isNull(actualKey)) && "day".equals(key)) actualKey = "morning";
        if ((!w.has(actualKey) || w.isNull(actualKey)) && "night".equals(key)) actualKey = "evening";
        if (!w.has(actualKey) || w.isNull(actualKey)) return "—°";
        double raw = w.optDouble(actualKey, Double.NaN);
        if (Double.isNaN(raw)) return "—°";
        long value = Math.round(raw);
        return (value < 0 ? "−" + Math.abs(value) : String.valueOf(value)) + "°";
    }

    private static String readWeatherIcon(SharedPreferences prefs, String place) {
        try {
            JSONObject all = new JSONObject(prefs.getString("weather_json", "{}"));
            JSONObject w = all.optJSONObject("home".equals(place) ? "home" : "work");
            if (w == null) return "🌤️";
            int code = w.optInt("weatherCode", -1);
            if (code == 0) return "☀️";
            if (code == 1 || code == 2) return "🌤️";
            if (code == 3) return "☁️";
            if (code == 45 || code == 48) return "🌫️";
            if ((code >= 51 && code <= 57) || (code >= 61 && code <= 67)) return "🌧️";
            if (code >= 71 && code <= 77) return "❄️";
            if (code >= 80 && code <= 82) return "🌦️";
            if (code >= 85 && code <= 86) return "🌨️";
            if (code >= 95) return "⛈️";
            return "🌡️";
        } catch (Exception ignored) {
            return "🌤️";
        }
    }

    private static void overridesPut(JSONObject object, String date, boolean value) {
        try { object.put(date, value); } catch (Exception ignored) { }
    }

    private static boolean isWorked(SharedPreferences prefs, String date) {
        return prefs.getBoolean("worked_" + date, false);
    }

    private static List<Period> readPeriods(SharedPreferences prefs) {
        List<Period> result = readPeriodArray(prefs.getString("periods_json", "[]"));
        if (!result.isEmpty()) return result;
        // Fallback used before the app has synced its calendar for the first time.
        result.add(new Period("2024-03-01", "2024-05-18", "historic", "Первая вахта"));
        result.add(new Period("2024-07-19", "2024-09-18", "historic", "Вахта"));
        result.add(new Period("2024-11-19", "2025-01-18", "historic", "Вахта"));
        for (int year = 2025; year <= 2035; year++) {
            if (year == 2025) {
                result.add(new Period("2025-02-19", "2025-03-18", "night", "Ночные смены"));
                result.add(new Period("2025-03-19", "2025-04-18", "day", "Дневные смены"));
                result.add(new Period("2025-06-19", "2025-07-18", "night", "Ночные смены"));
                result.add(new Period("2025-07-19", "2025-08-18", "day", "Дневные смены"));
                result.add(new Period("2025-10-19", "2025-11-18", "night", "Ночные смены"));
                result.add(new Period("2025-11-19", "2025-12-18", "day", "Дневные смены"));
            }
            if (year == 2026) {
                result.add(new Period("2026-02-19", "2026-03-18", "night", "Ночные смены"));
                result.add(new Period("2026-03-19", "2026-04-18", "day", "Дневные смены"));
                result.add(new Period("2026-06-19", "2026-07-18", "night", "Ночные смены"));
                result.add(new Period("2026-07-19", "2026-08-18", "day", "Дневные смены"));
                result.add(new Period("2026-10-19", "2026-11-18", "night", "Ночные смены"));
                result.add(new Period("2026-11-19", "2026-12-18", "day", "Дневные смены"));
            }
            if (year >= 2027) {
                result.add(new Period(year + "-02-19", year + "-03-18", "night", "Ночные смены"));
                result.add(new Period(year + "-03-19", year + "-04-18", "day", "Дневные смены"));
                result.add(new Period(year + "-06-19", year + "-07-18", "night", "Ночные смены"));
                result.add(new Period(year + "-07-19", year + "-08-18", "day", "Дневные смены"));
                result.add(new Period(year + "-10-19", year + "-11-18", "night", "Ночные смены"));
                result.add(new Period(year + "-11-19", year + "-12-18", "day", "Дневные смены"));
            }
        }
        return result;
    }

    private static List<Period> readExtras(SharedPreferences prefs) {
        return readPeriodArray(prefs.getString("extras_json", "[]"));
    }

    private static List<Period> readPeriodArray(String json) {
        List<Period> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String start = item.optString("start", "");
                String end = item.optString("end", "");
                if (start.length() != 10 || end.length() != 10 || start.compareTo(end) > 0) continue;
                result.add(new Period(start, end, item.optString("type", ""), item.optString("label", "")));
            }
        } catch (Exception ignored) { }
        return result;
    }

    private static Period periodOn(List<Period> periods, String date) {
        Period found = null;
        for (Period p : periods) if (date.compareTo(p.start) >= 0 && date.compareTo(p.end) <= 0) found = p;
        return found;
    }

    private static boolean isWorkingPeriod(Period period) {
        return period != null && isWorkType(period.type);
    }

    private static boolean isWorkDay(List<Period> periods, String date) {
        Period top = periodOn(periods, date);
        if (top != null && ("vacation".equals(top.type) || "sick".equals(top.type))) return false;
        for (Period p : periods) {
            if (date.compareTo(p.start) >= 0 && date.compareTo(p.end) <= 0 && isWorkType(p.type)) return true;
        }
        return false;
    }

    private static boolean isWorkType(String type) {
        return "night".equals(type) || "day".equals(type) || "historic".equals(type) || "extra".equals(type);
    }

    private static Period nextWorkPeriod(List<Period> periods, String today) {
        Period next = null;
        for (Period p : periods) {
            if (isWorkType(p.type) && p.start.compareTo(today) > 0
                    && (next == null || p.start.compareTo(next.start) < 0)) next = p;
        }
        return next;
    }

    private static int backgroundFor(Period period) {
        if (period == null) return COLOR_HOME;
        switch (period.type) {
            case "night": return COLOR_NIGHT;
            case "day": return COLOR_DAY;
            case "extra": return COLOR_EXTRA;
            case "vacation": return COLOR_VACATION;
            case "sick": return COLOR_SICK;
            default: return COLOR_HOME;
        }
    }

    private static String defaultLabel(String type) {
        switch (type) {
            case "night": return "Ночные смены";
            case "day": return "Дневные смены";
            case "historic": return "Вахта";
            case "extra": return "Подработка";
            case "vacation": return "Отпуск";
            case "sick": return "Больничный";
            default: return "Период";
        }
    }

    private static String iso(Calendar calendar) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(calendar.getTime());
    }

    private static String addDays(String source, int count) {
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(source));
            calendar.add(Calendar.DAY_OF_MONTH, count);
            return iso(calendar);
        } catch (Exception ignored) { return null; }
    }

    private static int daysBetween(String from, String to) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            format.setLenient(false);
            Date a = format.parse(from);
            Date b = format.parse(to);
            return (int) ((b.getTime() - a.getTime()) / 86400000L);
        } catch (Exception ignored) { return 0; }
    }

    private static String formatDate(String value) {
        try {
            Date date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(value);
            return new SimpleDateFormat("d MMM yyyy", new Locale("ru", "RU")).format(date);
        } catch (Exception ignored) { return value; }
    }
}
